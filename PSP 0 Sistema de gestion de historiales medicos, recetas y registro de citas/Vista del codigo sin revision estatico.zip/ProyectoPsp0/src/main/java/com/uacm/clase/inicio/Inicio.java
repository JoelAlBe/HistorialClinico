package com.uacm.clase.inicio;

/**
 *
 * @author joel-
 */
public class Inicio 
{
    public static void main(String[] args)
    {
        Receta receta = new Receta();
        
        receta.mostrarRecetas();
        
        Receta r1 = new Receta("28/10/98", "Brandon Joel Alba Berger", "28 años", "55 kg", "181 cm", "36.2 °c", "110/70 mmHg", "Hombre", "Ninguna", "Paracetamol 250 mg. cada 6 horas x 2 dias");
        Receta r2 = new Receta("11/07/94", "Francisco Rios Juarez", "20 años", "70 kg", "170 cm", "38.2 °c", "110/90 mmHg", "Hombre", "Penicilina", "Diclofenaco 100 mg. cada 12 horas x 4 dias");
        Receta r3 = new Receta("16/02/98", "Alejandra Torres Sanchez", "24 años", "65 kg", "169 cm", "32.2 °c", "110/102 mmHg", "Mujer", "Gluten", "Clonazepam 2 mg. cada 24 horas x 7 dias");  
        
        receta.guardarReceta(r1);
        receta.guardarReceta(r2);
        receta.guardarReceta(r3);
        
        receta.mostrarRecetas();
        
        receta.leerReceta();
        
        receta.actualizarReceta();
        
        receta.eliminarReceta();
        
        receta.mostrarRecetas();
        
        receta.llenarReceta();
        
        receta.mostrarRecetas();
        
 
        
    }
}
