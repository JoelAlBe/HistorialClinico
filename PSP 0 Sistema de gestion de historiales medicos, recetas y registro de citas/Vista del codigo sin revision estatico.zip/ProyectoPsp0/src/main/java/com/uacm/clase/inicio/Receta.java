package com.uacm.clase.inicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author joel-
 */
public class Receta 
{
    Scanner entrada = new Scanner(System.in);
    
    private String fecha;
    private String nombrePaciente;
    private String edadPaciente;
    private String pesoPaciente;
    private String tallaPaciente;
    private String temperaturaPaciente;
    private String presionArterialPaciente;
    private String sexoPaciente;
    private String alergiasPaciente;
    private String instrucciones;
    
    public static List<Receta> listaRecetas;
    
    public Receta(String fecha, String nombrePaciente, String edadPaciente, String pesoPaciente, 
                  String tallaPaciente, String temperaturaPaciente, String presionArterialPaciente, 
                  String sexoPaciente, String alergiasPaciente, String instrucciones)
    {
        this.fecha = fecha;
        this.nombrePaciente = nombrePaciente;
        this.edadPaciente = edadPaciente;
        this.pesoPaciente = pesoPaciente;
        this.tallaPaciente = tallaPaciente;
        this.temperaturaPaciente = temperaturaPaciente;
        this.presionArterialPaciente = presionArterialPaciente;
        this.sexoPaciente = sexoPaciente;
        this.alergiasPaciente = alergiasPaciente;
        this.instrucciones = instrucciones;
        
        listaRecetas = new ArrayList();
    }
    
    public Receta()
    {
        
    }

    public String getFecha()
    {
        return fecha;
    }

    public void setFecha(String fecha) 
    {
        this.fecha = fecha;
    }

    public String getNombrePaciente() 
    {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) 
    {
        this.nombrePaciente = nombrePaciente;
    }

    public String getEdadPaciente() 
    {
        return edadPaciente;
    }

    public void setEdadPaciente(String edadPaciente) 
    {
        this.edadPaciente = edadPaciente;
    }

    public String getPesoPaciente() 
    {
        return pesoPaciente;
    }

    public void setPesoPaciente(String pesoPaciente) 
    {
        this.pesoPaciente = pesoPaciente;
    }

    public String getTallaPaciente() 
    {
        return tallaPaciente;
    }

    public void setTallaPaciente(String tallaPaciente) 
    {
        this.tallaPaciente = tallaPaciente;
    }

    public String getTemperaturaPaciente() 
    {
        return temperaturaPaciente;
    }

    public void setTemperaturaPaciente(String temperaturaPaciente) 
    {
        this.temperaturaPaciente = temperaturaPaciente;
    }

    public String getPresionArterialPaciente() 
    {
        return presionArterialPaciente;
    }

    public void setPresionArterialPaciente(String presionArterialPaciente) 
    {
        this.presionArterialPaciente = presionArterialPaciente;
    }

    public String getSexoPaciente() 
    {
        return sexoPaciente;
    }

    public void setSexoPaciente(String sexoPaciente) 
    {
        this.sexoPaciente = sexoPaciente;
    }

    public String getAlergiasPaciente() 
    {
        return alergiasPaciente;
    }

    public void setAlergiasPaciente(String alergiasPaciente) 
    {
        this.alergiasPaciente = alergiasPaciente;
    }

    public String getInstrucciones() 
    {
        return instrucciones;
    }

    public void setInstrucciones(String instrucciones) 
    {
        this.instrucciones = instrucciones;
    }
    
    public void mostrarRecetas()
    {
        for(Receta aux: listaRecetas)
        {
            aux.toString();
        }
        
        System.out.println("No hay recetas en la base de datos.");
    }
    
    public void guardarReceta(Receta receta)
    {
        listaRecetas.add(receta);
    }
    
    private Receta buscarReceta(String nombre)
    {
        for(Receta aux: listaRecetas)
        {
            if(nombre.equals(aux.nombrePaciente))
            {
                return aux;
            }
        }
        
        System.out.println("La receta que esta buscando no se encuentra en la base de datos.");
        return null;
    }
    
    public void llenarReceta()
    {
        System.out.println("Llenado de receta...");
        
        System.out.println("Ingrese la fecha de la siguiente manera (dd/mm/mmmm):");
        String fecha = entrada.nextLine();
        setFecha(fecha);
        
        System.out.println("Ingrese el nombre completo del paciente:");
        String nombre = entrada.nextLine();
        setNombrePaciente(nombre);
        
        System.out.println("Ingrese la edad del paciente:");
        String edad = entrada.nextLine();
        setEdadPaciente(edad);
        
        System.out.println("Ingrese el peso del paciente:");
        String peso = entrada.nextLine();
        setPesoPaciente(peso);
        
        System.out.println("Ingrese la talla del paciente:");
        String estatura = entrada.nextLine();
        setTallaPaciente(estatura);
        
        System.out.println("Ingrese la temperatura del paciente:");
        String temperatura = entrada.nextLine();
        setTemperaturaPaciente(temperatura);
        
        System.out.println("Ingrese la presion arterial del paciente:");
        String presion = entrada.nextLine();
        setPresionArterialPaciente(presion);
        
        System.out.println("Ingrese el sexo del paciente:");
        String sexo = entrada.nextLine();
        setSexoPaciente(sexo);
        
        System.out.println("Ingrese las alergias del paciente:");
        String alergias = entrada.nextLine();
        setAlergiasPaciente(alergias);
        
        System.out.println("Ingrese las instrucciones a seguir:");
        String rx = entrada.nextLine();
        setInstrucciones(rx);
        
        Receta r = new Receta(fecha, nombre, edad, peso, estatura, temperatura, presion, sexo, alergias, rx);
        listaRecetas.add(r);
        
        System.out.println("Receta agregada exitosamente...");
    }
    
    public void eliminarReceta()
    {
        System.out.println("Eliminar receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        Object a = buscarReceta(nombre);
        
        System.out.println("¿Desea eliminar receta? s=Si, n=No");
        char respuesta = entrada.next().charAt(0);
        
        if(respuesta == 's')
        {
            listaRecetas.remove(a);
            System.out.println("De acuerdo, la receta ha dico eliminada...");
        }
        
        else
        {
            System.out.println("De acuerdo, la receta no ha dico eliminada...");
        }
    }
    
    public void actualizarReceta()
    {   
        System.out.println("Actualizar receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        
        for(Receta aux: listaRecetas)
        {
            if(nombre.equals(aux.nombrePaciente))
            {
                System.out.println("Ingrese la fecha de la siguiente manera (dd/mm/mmmm):");
                String fecha = entrada.nextLine();
        aux.setFecha(fecha);
        
        System.out.println("Ingrese el nombre completo del paciente:");
        String name = entrada.nextLine();
        aux.setNombrePaciente(name);
        
        System.out.println("Ingrese la edad del paciente:");
        String edad = entrada.nextLine();
        aux.setEdadPaciente(edad);
        
        System.out.println("Ingrese el peso del paciente:");
        String peso = entrada.nextLine();
        aux.setPesoPaciente(peso);
        
        System.out.println("Ingrese la talla del paciente:");
        String estatura = entrada.nextLine();
        aux.setTallaPaciente(estatura);
        
        System.out.println("Ingrese la temperatura del paciente:");
        String temperatura = entrada.nextLine();
        aux.setTemperaturaPaciente(temperatura);
        
        System.out.println("Ingrese la presion arterial del paciente:");
        String presion = entrada.nextLine();
        aux.setPresionArterialPaciente(presion);
        
        System.out.println("Ingrese el sexo del paciente:");
        String sexo = entrada.nextLine();
        aux.setSexoPaciente(sexo);
        
        System.out.println("Ingrese las alergias del paciente:");
        String alergias = entrada.nextLine();
        aux.setAlergiasPaciente(alergias);
        
        System.out.println("Ingrese las instrucciones a seguir:");
        String rx = entrada.nextLine();
        aux.setInstrucciones(rx);
        
        System.out.println("Receta agregada exitosamente...");
            }
        }
        
        System.out.println("La receta que esta buscando no se encuentra en la base de datos.");
    }
    
    public void leerReceta()
    {
        int flag = 0;
        System.err.println("Leer receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        
        for(Receta aux: listaRecetas)
        {
            if(nombre.equals(aux.getNombrePaciente()))
            {
                aux.toString();
                flag=1;
                
            }
        }
        
        if(flag==0)
        {
            System.out.println("La receta que intenta buscar, no se encuentra en la base de datos...");
        }
    }

    @Override
    public String toString() 
    {
        return "Receta --> " + "fecha: " + fecha + ", Nombre del paciente: " + nombrePaciente + "Edad del paciente: " + edadPaciente + ", Peso del paciente: " + pesoPaciente + ", Talla del paciente: " + tallaPaciente + ", Temperatura del paciente: " + temperaturaPaciente + ", Presion arterial del paciente: " + presionArterialPaciente + ", Sexo del paciente: " + sexoPaciente + ", Alergias del paciente: " + alergiasPaciente + ", Rx: " + instrucciones + '}';
    }
}