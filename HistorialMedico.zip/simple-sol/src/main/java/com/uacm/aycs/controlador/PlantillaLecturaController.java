package com.uacm.aycs.controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author joel-
 */
public class PlantillaLecturaController implements Initializable 
{

    @FXML
    private TextField fecha;
    @FXML
    private TextField nombrePaciente;
    @FXML
    private TextField edad;
    @FXML
    private TextField peso;
    @FXML
    private TextField talla;
    @FXML
    private TextField temperatura;
    @FXML
    private TextField presion;
    @FXML
    private TextArea alergias;
    @FXML
    private TextArea medicamentos;
    @FXML
    private TextField sexo;
    @FXML
    private TextField noSeguroField;
    
    private String fechaReceta;
    private String nombre;
    private String edadPaciente;
    private String pesoPaciente;
    private String tallaPaciente;
    private String temperaturaPaciente;
    private String presionPaciente;
    private String sexoPaciente;
    private String alergiasPaciente;
    private String rx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
    }    


    @FXML
    private void limpiarCampos(ActionEvent event) 
    {
        fecha.setText("");
        nombrePaciente.setText("");
        edad.setText("");
        peso.setText("");
        talla.setText("");
        temperatura.setText("");
        presion.setText("");
        sexo.setText("");
        alergias.setText("");
        medicamentos.setText("");
    }

    @FXML
    private void mostrarInfo(ActionEvent event) 
    {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/Informacion.fxml"));
            
            Stage secundaryStage = new Stage();
            Pane pane = (Pane) loader.load();
            
            Scene scene = new Scene(pane);
            
            secundaryStage.initModality(Modality.APPLICATION_MODAL);
            secundaryStage.setScene(scene);
            secundaryStage.showAndWait();
        } catch (IOException ex) {
            Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);     
        }
    }

    @FXML
    private void cerrarVentana(ActionEvent event) 
    {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close(); 
    }
    
    public void leerDatos(String fecha, String nombre, String edad, String peso, String talla, 
                          String temperatura, String presion, String alergias, String medicamentos)
    {
        this.fecha.setText(fecha);
        this.nombrePaciente.setText(nombre);
        this.edad.setText(edad);
        this.peso.setText(peso);
        this.talla.setText(talla);
        this.temperatura.setText(temperatura);
        this.presion.setText(presion);
        this.alergias.setText(alergias);
        this.medicamentos.setText(medicamentos);
    }

    public void setFechaReceta(String fechaReceta) 
    {
        this.fechaReceta = fechaReceta;
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }

    public void setEdadPaciente(String edadPaciente) 
    {
        this.edadPaciente = edadPaciente;
    }

    public void setPesoPaciente(String pesoPaciente) 
    {
        this.pesoPaciente = pesoPaciente;
    }

    public void setTallaPaciente(String tallaPaciente) 
    {
        this.tallaPaciente = tallaPaciente;
    }

    public void setTemperaturaPaciente(String temperaturaPaciente) 
    {
        this.temperaturaPaciente = temperaturaPaciente;
    }

    public void setPresionPaciente(String presionPaciente) 
    {
        this.presionPaciente = presionPaciente;
    }

    public void setSexoPaciente(String sexoPaciente) 
    {
        this.sexoPaciente = sexoPaciente;
    }

    public void setAlergiasPaciente(String alergiasPaciente) 
    {
        this.alergiasPaciente = alergiasPaciente;
    }

    public void setRx(String rx) 
    {
        this.rx = rx;
    }
    
    public void insertar()
    {
        this.fecha.setText(fechaReceta);
        this.nombrePaciente.setText(nombre);
        this.edad.setText(edadPaciente);
                
    }
}