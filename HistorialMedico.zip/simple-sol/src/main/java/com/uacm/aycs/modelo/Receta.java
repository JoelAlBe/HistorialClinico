package com.uacm.aycs.modelo;

import com.uacm.aycs.clases.conexionBD;
import com.uacm.aycs.controlador.PlantillaLecturaController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

/**
 * Clase: Receta.
 * Version : Final de psp0.
 * copyright.
 * @author joel-
 */
public class Receta 
{   
    private String fecha;
    private String nombreCompleto;
    private String edad;
    private String peso;
    private String talla;
    private String temperatura;
    private String tension;
    private String sexo;
    private String alergias;
    private String rx;
    
    public Receta()
    {
        //Constructor vacio.
    }
    
    //Métodos declarados como modelado de negocio en la clase.
    public int guardarReceta(String fecha, String nombre_completo, String edad, String peso, String talla, String temperatura, String presion, String sexo, String alergias, String indicaciones) throws SQLException
    {
        int flag = 0;
        
        try {
                Connection con = conexionBD.conectar();
                PreparedStatement p = con.prepareStatement("insert into pacientes values(?,?,?,?,?,?,?,?,?,?,?)");
                p.setInt(1, 0);
                p.setString(2, fecha);
                p.setString(3, nombre_completo);
                p.setString(4, edad);
                p.setString(5, peso);
                p.setString(6, talla);
                p.setString(7, temperatura);
                p.setString(8, presion);
                p.setString(9, sexo);
                p.setString(10, alergias);
                p.setString(11, indicaciones);
                p.executeUpdate();
                con.close();
                
                flag = 1;
                
        }catch(Exception e){
            System.err.println("Error al registrar..."+e);
            flag = 0;
        } 
        
        if(flag==1)
        {
            return 1;
        }
        
        else
        {
            return 0;
        }
    }
    
    public boolean buscarReceta(String noSeguro)
    {   
        boolean respuesta = false;
        int cont = 0; 
        
        try {
            Connection con = conexionBD.conectar();
            String sql = "SELECT * FROM pacientes WHERE no_seguro = "+noSeguro;
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) 
            {
                cont += 1;
            }
            
            if(cont > 0)
                respuesta = true;
            
            con.close();
        } catch (Exception e) {
            System.err.println(e); 
        }
        
        return respuesta;
    }
    
    public boolean eliminarReceta(String noSeguro) throws SQLException
    {
        boolean respuesta = false;
        
        Connection con = conexionBD.conectar();
        String comSQL = "";
        Statement st;
        if(con != null){
            try{
                comSQL = "delete from pacientes where no_seguro = " + noSeguro + ";";
                st = con.createStatement();
                int res = st.executeUpdate(comSQL);

                if(res>0)
                    respuesta=true;
            }catch(SQLException e){
                System.out.println(e);
            }finally{
                con.close();
            }
        }
        
        return respuesta;
    }
    
    public boolean actualizarReceta(int id, String nombre, String edad, String fecha) throws SQLException
    {   
       boolean respuesta;

       String query = "UPDATE pacientes SET fecha=?, nombre_completo=?, edad=? WHERE no_seguro = ?"+id; 
       Connection con = conexionBD.conectar(); 
       con.setAutoCommit(false);
       
       PreparedStatement stmt = con.prepareStatement(query);
       stmt.setString(1, "fecha"); //El numero 1 es el signo ? que esta en el query
       stmt.setString(2, "nombre_completo"); //El numero 2 es del signo ? que esta en el query
       stmt.setString(3, "edad"); //El numero 3 es del signo ? que esta en el query
       int res = stmt.executeUpdate();
       stmt.close();
       
       respuesta = (res>0)?true:false;
       
       return respuesta;
    } 
    
    public boolean leerReceta(String noSeguro) throws SQLException
    {   
        boolean respuesta = false;
        FXMLLoader loader = new FXMLLoader();
        
        
        try {
            
            Connection con = conexionBD.conectar();
            String sql = "SELECT * FROM pacientes WHERE no_seguro = "+noSeguro;
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) 
            {
                 String area = rs.getString("no_seguro");
                 if(noSeguro.equals(area))
                 {
                    fecha = rs.getString("fecha");
                    nombreCompleto = rs.getString("nombre_completo");
                    edad = rs.getString("edad");
                    peso = rs.getString("peso");
                    talla = rs.getString("talla");
                    temperatura = rs.getString("temperatura");
                    tension = rs.getString("presion");
                    sexo = rs.getString("sexo");
                    alergias = rs.getString("alergias");
                    rx = rs.getString("indicaciones");
                    
                    PlantillaLecturaController p = (PlantillaLecturaController) loader.getController();
                    p.setFechaReceta(fecha);
                    p.setNombre(nombreCompleto);
                    p.setEdadPaciente(edad);
                    p.setPesoPaciente(peso);
                    p.setTallaPaciente(talla);
                    p.setTemperaturaPaciente(temperatura);
                    p.setPresionPaciente(tension);
                    p.setSexoPaciente(sexo);
                    p.setAlergiasPaciente(alergias);
                    p.setRx(rx);
                    //Stage secundaryStage = new Stage(); <--- Aquí esta el error.
                    //p.insertar(fecha, nombreCompleto, edad, peso, talla, temperatura, peso, alergias, rx);
                    
                    respuesta = true;
                 } 
            }
            
            
        } catch (SQLException e) {
            System.err.println(e); 
        }
        return respuesta;
    }
}