package com.uacm.aycs.controlador;

import com.uacm.aycs.modelo.Receta;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author joel-
 */
public class ConfirmacionController implements Initializable
{
    private String seguro;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
    
    }    

    @FXML
    private void confirmarAccion(ActionEvent event) throws SQLException 
    {   
        
        boolean respuesta;
        Receta r = new Receta();
        System.out.println(seguro);
        respuesta = r.eliminarReceta(seguro);
        
        if(respuesta == true)
        {
             try {   
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/Correcto.fxml"));
                
                Stage secundaryStage = new Stage();
                Pane pane = (Pane) loader.load();
                
                Scene scene = new Scene(pane);
            
                secundaryStage.initModality(Modality.APPLICATION_MODAL);
                secundaryStage.setScene(scene);
                secundaryStage.showAndWait();
            
            } catch (IOException ex) {
                Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);     
            }
        }
        
        else
        {
            try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/Error.fxml"));
            
                    Stage secundaryStage = new Stage();
                    Pane pane = (Pane) loader.load();
            
                    Scene scene = new Scene(pane);
            
                    secundaryStage.initModality(Modality.APPLICATION_MODAL);
                    secundaryStage.setScene(scene);
                    secundaryStage.showAndWait();
                
                } catch (IOException ex) {
                    Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);     
                }
        }
        
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void negarAccion(ActionEvent event) 
    {
        
        try {
             
            Node source = (Node) event.getSource();
            Stage stage = (Stage) source.getScene().getWindow();
            stage.close();
                
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/Cancelacion.fxml"));
            
            Stage secundaryStage = new Stage();
            Pane pane = (Pane) loader.load();
            
            Scene scene = new Scene(pane);
            
            secundaryStage.initModality(Modality.APPLICATION_MODAL);
            secundaryStage.setScene(scene);
            secundaryStage.showAndWait();
                
        } catch (IOException ex) {
                Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);     
        }
        
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    public void setSeguro(String seguro) 
    {
        this.seguro = seguro;
    }
}