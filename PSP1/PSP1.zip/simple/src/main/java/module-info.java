module com.uacm.aycs.controlador 
{
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.uacm.aycs.controlador to javafx.fxml;
    exports com.uacm.aycs.controlador;
}

