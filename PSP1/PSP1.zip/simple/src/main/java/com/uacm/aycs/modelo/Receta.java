package com.uacm.aycs.modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Clase: Receta.
 * Version : Final de psp0.
 * copyright.
 * @author joel-
 */
public class Receta 
{
    //Delcarado para la entrada de datos por medio del teclado en medio de la compilacion.
    Scanner entrada = new Scanner(System.in);
    
    private String fecha;
    private String nombrePaciente;
    private String edadPaciente;
    private String pesoPaciente;
    private String tallaPaciente;
    private String temperaturaPaciente;
    private String presionArterialPaciente;
    private String sexoPaciente;
    private String alergiasPaciente;
    private String instrucciones;
    
    private List<Receta> listaRecetas = new ArrayList<>();
    
    public Receta(String fecha, String nombrePaciente, String edadPaciente, String pesoPaciente, 
                  String tallaPaciente, String temperaturaPaciente, String presionArterialPaciente, 
                  String sexoPaciente, String alergiasPaciente, String instrucciones)
    {
        this.fecha = fecha;
        this.nombrePaciente = nombrePaciente;
        this.edadPaciente = edadPaciente;
        this.pesoPaciente = pesoPaciente;
        this.tallaPaciente = tallaPaciente;
        this.temperaturaPaciente = temperaturaPaciente;
        this.presionArterialPaciente = presionArterialPaciente;
        this.sexoPaciente = sexoPaciente;
        this.alergiasPaciente = alergiasPaciente;
        this.instrucciones = instrucciones;
    }
    
    public Receta()
    {
        //Constructor vacio.
    }

    //Métodos get and set de los atributos declarados en la clase.
    public String getFecha()
    {
        return fecha;
    }

    public void setFecha(String fecha) 
    {
        this.fecha = fecha;
    }

    public String getNombrePaciente() 
    {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) 
    {
        this.nombrePaciente = nombrePaciente;
    }

    public String getEdadPaciente() 
    {
        return edadPaciente;
    }

    public void setEdadPaciente(String edadPaciente) 
    {
        this.edadPaciente = edadPaciente;
    }

    public String getPesoPaciente() 
    {
        return pesoPaciente;
    }

    public void setPesoPaciente(String pesoPaciente) 
    {
        this.pesoPaciente = pesoPaciente;
    }

    public String getTallaPaciente() 
    {
        return tallaPaciente;
    }

    public void setTallaPaciente(String tallaPaciente) 
    {
        this.tallaPaciente = tallaPaciente;
    }

    public String getTemperaturaPaciente() 
    {
        return temperaturaPaciente;
    }

    public void setTemperaturaPaciente(String temperaturaPaciente) 
    {
        this.temperaturaPaciente = temperaturaPaciente;
    }

    public String getPresionArterialPaciente() 
    {
        return presionArterialPaciente;
    }

    public void setPresionArterialPaciente(String presionArterialPaciente) 
    {
        this.presionArterialPaciente = presionArterialPaciente;
    }

    public String getSexoPaciente() 
    {
        return sexoPaciente;
    }

    public void setSexoPaciente(String sexoPaciente) 
    {
        this.sexoPaciente = sexoPaciente;
    }

    public String getAlergiasPaciente() 
    {
        return alergiasPaciente;
    }

    public void setAlergiasPaciente(String alergiasPaciente) 
    {
        this.alergiasPaciente = alergiasPaciente;
    }

    public String getInstrucciones() 
    {
        return instrucciones;
    }

    public void setInstrucciones(String instrucciones) 
    {
        this.instrucciones = instrucciones;
    }
    
    //Métodos declarados como modelado de negocio en la clase.
    
    //Método para mostrar todas las recetas sin solicitar un nombre.
    public void mostrarRecetas()
    {
         Receta paciente;
         int i = 1;
        
         if(listaRecetas.isEmpty())
         {
            System.out.println("No hay recetas dentro de la lista..."); 
         }
         
         else
         {
            for(Object aux: listaRecetas)
            {
                paciente = (Receta) aux;
                System.out.println("Paciente "+i+": "+paciente.getFecha()+" Nombre: "+paciente.getNombrePaciente()+" Edad: "+paciente.getEdadPaciente()
                                   +" Sexo: "+paciente.getSexoPaciente()+" Peso: "+paciente.getPesoPaciente()+" Estatura: "+paciente.getTallaPaciente()+" Temperatura: "
                                   +paciente.getTemperaturaPaciente()+" Ta: "+paciente.getPresionArterialPaciente()+" Alergias: "
                                   +paciente.getAlergiasPaciente()+" Rx: "+paciente.getInstrucciones());    
                i++;
            } 
         }
    }
    
    public void guardarReceta(Receta receta)
    {
        listaRecetas.add(receta);
        System.out.println("Receta agregada exitosamente...");
    }
    
    //Se declara como privado ya que no va a ser usada en otras clases más que en esta para realizar busquedas y dar el resultado
    //a otros metodos implementados en esta clase.
    private Receta buscarReceta(String nombre)
    {
        for(Receta aux: listaRecetas)
        {
            if(nombre.equals(aux.nombrePaciente))
            {
                return aux;
            }
        }
        
        System.out.println("La receta que esta buscando no se encuentra en la lista, presione enter.");
        entrada.nextLine();
        return null;
    }
    
    public Receta llenarReceta()
    {
        System.out.println("Llenado de receta...");
        
        System.out.println("Ingrese la fecha de la siguiente manera (dd/mm/mmmm):");
        String fecha = entrada.nextLine();
        
        System.out.println("Ingrese el nombre completo del paciente:");
        String nombre = entrada.nextLine();
        
        System.out.println("Ingrese la edad del paciente:");
        String edad = entrada.nextLine();
        
        System.out.println("Ingrese el peso del paciente:");
        String peso = entrada.nextLine();
        
        System.out.println("Ingrese la talla del paciente:");
        String estatura = entrada.nextLine();
        
        System.out.println("Ingrese la temperatura del paciente:");
        String temperatura = entrada.nextLine();
        
        System.out.println("Ingrese la presion arterial del paciente:");
        String presion = entrada.nextLine();
        
        System.out.println("Ingrese el sexo del paciente:");
        String sexo = entrada.nextLine();
        
        System.out.println("Ingrese las alergias del paciente:");
        String alergias = entrada.nextLine();
        
        System.out.println("Ingrese las instrucciones a seguir:");
        String rx = entrada.nextLine();
        
        Receta r = new Receta(fecha, nombre, edad, peso, estatura, temperatura, presion, sexo, alergias, rx);
        
        System.out.println("Receta agregada exitosamente, presione enter...");
        entrada.nextLine();
        
        return r;
       
    }
    
    public void eliminarReceta()
    {
        System.out.println("Eliminar receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        Receta aux = buscarReceta(nombre);
        
        if(aux != null)
        {
            if(nombre.equals(aux.getNombrePaciente()))
            {
                System.out.println("Desea eliminar receta? s=Si, n=No");
                char respuesta = entrada.next().charAt(0);
        
                if(respuesta == 's')
                {
                    listaRecetas.remove(aux);
                    System.out.println("De acuerdo, la receta ha dico eliminada, presione enter...");
                    entrada.nextLine();
                }
        
                else
                {
                    System.out.println("De acuerdo, la receta no ha dico eliminada, presione enter...");
                    entrada.nextLine();
                } 
            }
        }
    }
    
    public void actualizarReceta()
    {   int flag = 0;
    
        System.out.println("Actualizar receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        
        for(Receta aux: listaRecetas)
        {
            if(nombre.equals(aux.nombrePaciente))
            {
                System.out.println("Ingrese la nueva fecha de la siguiente manera (dd/mm/mmmm):");
                String fecha = entrada.nextLine();
                aux.setFecha(fecha);
        
                System.out.println("Ingrese el nuevo nombre completo del paciente:");
                String name = entrada.nextLine();
                aux.setNombrePaciente(name);
        
                System.out.println("Ingrese la nueva edad del paciente:");
                String edad = entrada.nextLine();
                aux.setEdadPaciente(edad);
        
                System.out.println("Receta actualizada exitosamente, presione enter...");
                entrada.nextLine();
                
                flag = 1;
            }
        }
        
        if(flag == 0)
        {
            System.out.println("La receta que esta buscando no se encuentra en la lista, presione enter.");
            entrada.nextLine();
        }
    }
    
    //Con diferencia de el primer metodo dentro del modelado de negocio, este lee la receta, pero con la diferencia de que 
    //aqui se solicita el nombre para hacer la busqueda y sólo leer una receta en especifico.
    public void leerReceta()
    {
        int flag = 0;
        int i = 1;
        
        System.out.println("Leer receta...");
        System.out.println("Ingrese el nombre del paciente: ");
        String nombre = entrada.nextLine();
        
        for(Receta paciente: listaRecetas)
        {
            if(nombre.equals(paciente.getNombrePaciente()))
            {
                System.out.println("Fecha: "+paciente.getFecha()+" Nombre: "+paciente.getNombrePaciente()+" Edad: "+paciente.getEdadPaciente()
                                   +" Sexo: "+paciente.getSexoPaciente()+" Peso: "+paciente.getPesoPaciente()+" Estatura: "+paciente.getTallaPaciente()+" Temperatura: "
                                   +paciente.getTemperaturaPaciente()+" Ta: "+paciente.getPresionArterialPaciente()+" Alergias: "
                                   +paciente.getAlergiasPaciente()+"Rx: "+paciente.getInstrucciones()); 
                flag = 1; 
            }
        }
        
        if(flag == 0)
        {
            System.out.println("La receta que intenta buscar, no se encuentra en la lista, presione enter...");
            entrada.nextLine();
        }
    }
}