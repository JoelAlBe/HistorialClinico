package com.uacm.aycs.controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author joel-
 */
public class PlantillaRecetaController implements Initializable 
{

    @FXML
    private TextField fecha;
    @FXML
    private TextField nombrePaciente;
    @FXML
    private TextField edad;
    @FXML
    private TextField peso;
    @FXML
    private TextField talla;
    @FXML
    private TextField temperatura;
    @FXML
    private TextField presion;
    @FXML
    private SplitMenuButton sexo;
    @FXML
    private TextArea alergias;
    @FXML
    private TextArea medicamentos;
    @FXML
    private MenuItem buscarRecetas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    

    @FXML
    private void guardarReceta(ActionEvent event) 
    {
        
    }

    @FXML
    private void cerrarVentana(ActionEvent event) 
    {
        
    }

    @FXML
    private void limpiarCampos(ActionEvent event)
    {
        
    }

    @FXML
    private void mostrarInfo(ActionEvent event) 
    {
        
    }   

    @FXML
    private void buscarRecetas(ActionEvent event) 
    {
        
    }
}